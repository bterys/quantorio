data:extend(
{
  {
    type = "spectator-controller",
    name = "default",
    movement_speed = 0.5
  }
})
